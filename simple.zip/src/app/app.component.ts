import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    Nname;
    Ncategory;
    Nsize;
    index;
    productList = [{ name : "chudi Material", category : "Material", size : "30"},
                  { name : "Saree Material", category : "ReadyMade", size : "40"} ];
    
    onAdd(){
      if(this.Nname && this.Ncategory && this.Nsize !== ""){
        let newProduct = {
          name : this.Nname,
          category : this.Ncategory,
          size : this.Nsize
        }
        this.productList.push(newProduct)
        this.Nname='';
        this.Ncategory='';
        this.Nsize='';
      }
    }
    onClick(i){
    console.log(i,"i")
    this.index = i;
    this.Nname = this.productList[i].name;
    this.Ncategory = this.productList[i].category;
    this.Nsize = this.productList[i].size;
    }
    onDelete(){
      this.productList.splice(this.index , 1);
      this.Nname='';
      this.Ncategory='';
      this.Nsize='';
    }
    onEdit(){
      console.log("manju", this.index)
      this.productList[this.index].name = this.Nname; 
      this.productList[this.index].category = this.Ncategory;
      this.productList[this.index].size = this.Nsize;
      this.Nname='';
      this.Ncategory='';
      this.Nsize='';
    }
}
